/* eslint-disable prettier/prettier */
import {
  Provider as PaperProvider,
  BottomNavigation,
  Button,
  FAB,
  Appbar,
  MD2Colors,
  MD3Colors,
  NonExistent,
  NonExistentSecond as Stuff,
  ThemeProvider,
  withTheme,
  DefaultTheme,
} from 'react-native-paper';
