export { default as Caption } from './Caption';
export { default as Headline } from './Headline';
export { default as Paragraph } from './Paragraph';
export { default as Subheading } from './Subheading';
export { default as Title } from './Title';
