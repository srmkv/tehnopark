// @component ./AvatarIcon.tsx
export { default as Icon } from './AvatarIcon';

// @component ./AvatarImage.tsx
export { default as Image } from './AvatarImage';

// @component ./AvatarText.tsx
export { default as Text } from './AvatarText';
