module.exports = require('./lib/module/babel/index.js');
