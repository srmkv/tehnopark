/// <reference types="react" />
declare const AppbarBackIcon: ({ size, color }: {
    size: number;
    color: string;
}) => JSX.Element;
export default AppbarBackIcon;
export { AppbarBackIcon };
