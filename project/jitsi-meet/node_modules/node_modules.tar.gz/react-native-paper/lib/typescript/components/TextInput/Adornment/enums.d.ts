export declare enum AdornmentType {
    Icon = "icon",
    Affix = "affix"
}
export declare enum AdornmentSide {
    Right = "right",
    Left = "left"
}
export declare enum InputMode {
    Outlined = "outlined",
    Flat = "flat"
}
