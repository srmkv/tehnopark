import type { InternalTheme } from '../../types';
export declare const getToggleButtonColor: ({ theme, checked, }: {
    theme: InternalTheme;
    checked: boolean | null;
}) => string;
