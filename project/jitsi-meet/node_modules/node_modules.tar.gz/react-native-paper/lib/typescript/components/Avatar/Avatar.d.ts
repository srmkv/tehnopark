export { default as Icon } from './AvatarIcon';
export { default as Image } from './AvatarImage';
export { default as Text } from './AvatarText';
