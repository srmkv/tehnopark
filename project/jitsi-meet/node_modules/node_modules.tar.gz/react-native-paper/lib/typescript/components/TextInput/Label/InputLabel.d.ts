/// <reference types="react" />
import type { InputLabelProps } from '../types';
declare const InputLabel: (props: InputLabelProps) => JSX.Element | null;
export default InputLabel;
