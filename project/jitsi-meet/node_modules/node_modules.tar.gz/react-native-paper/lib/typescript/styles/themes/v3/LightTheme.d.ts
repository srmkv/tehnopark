import type { MD3Theme } from '../../../types';
export declare const MD3LightTheme: MD3Theme;
