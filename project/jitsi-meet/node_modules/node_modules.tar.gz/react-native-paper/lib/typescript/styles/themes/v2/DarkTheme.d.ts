import type { MD2Theme } from '../../../types';
export declare const MD2DarkTheme: MD2Theme;
