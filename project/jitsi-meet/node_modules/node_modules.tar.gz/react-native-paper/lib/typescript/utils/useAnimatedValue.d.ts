import { Animated } from 'react-native';
export default function useAnimatedValue(initialValue: number): Animated.Value;
