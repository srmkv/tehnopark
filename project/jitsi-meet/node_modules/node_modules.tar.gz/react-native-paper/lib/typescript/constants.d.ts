export declare const APPROX_STATUSBAR_HEIGHT: any;
