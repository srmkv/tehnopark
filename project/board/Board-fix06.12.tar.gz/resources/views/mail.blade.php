<h1>Hi, {{ $name }}</h1>
<p>Sending Mail from Laravel.</p>
